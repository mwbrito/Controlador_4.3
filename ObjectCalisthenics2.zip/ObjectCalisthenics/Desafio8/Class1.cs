﻿//public class Depois
//{
//    public void CadastrarUsuario(string nome, string email)
//    {
//        Console.WriteLine($"Nome: {nome}, Email: {email}");
//    }
//}
