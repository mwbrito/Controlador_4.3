﻿using System;

class Program
{
    static void Main()
    {
        Desafio desafio = new Desafio();
        desafio.CadastrarUsr("marcos", "marcos@itau.com");

        Console.ReadKey();
    }
}

public class Desafio
{
    public void CadastrarUsr(string nm, string em)
    {
        Console.WriteLine($"Nome: {nm}, Email: {em}");
    }
}
