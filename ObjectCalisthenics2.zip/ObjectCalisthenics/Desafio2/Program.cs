﻿public class Program
{
    static void Main()
    {
        var pedido = new Pedido
        {
            Produto = "Mouse",
            Quantidade = 7,
            Preco = 50.0m,
            Email = "cliente@exemplo.com"
        };

        var antes = new PedidoService();
        antes.ProcessarPedido(pedido);

        Console.ReadKey();
    }
}

public class Pedido
{
    public string Produto { get; set; }
    public int Quantidade { get; set; }
    public decimal Preco { get; set; }
    public string Email { get; set; }
}


public class PedidoService
{
    public void ProcessarPedido(Pedido pedido)
    {
        // Validação
        if (string.IsNullOrWhiteSpace(pedido.Produto))
        {
            Console.WriteLine("Produto inválido.");
            return;
        }

        if (pedido.Quantidade <= 0)
        {
            Console.WriteLine("Quantidade inválida.");
            return;
        }

        // Cálculo do frete
        decimal frete = 10.0m;
        if (pedido.Quantidade > 5)
        {
            frete += 5.0m;
        }

        // Processamento
        decimal total = pedido.Preco * pedido.Quantidade + frete;
        Console.WriteLine($"Total do pedido: {total}");

        // Notificação
        Console.WriteLine($"Enviando e-mail de confirmação para {pedido.Email}...");
    }
}
