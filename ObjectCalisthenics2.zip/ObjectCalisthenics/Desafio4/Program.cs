﻿class Desafio4
{
    static void Main()
    {
        Process(new User());
        Console.ReadKey();
    }

    public static void Process(User user)
    {
        if (user != null)
        {
            if (user.IsActive)
            {
                if (user.Permissions != null)
                {
                    foreach (var p in user.Permissions)
                    {
                        if (p.StartsWith("Admin"))
                        {
                            Console.WriteLine("Admin: " + p);
                        }
                    }
                }
            }
        }
    }
}

public class User
{
    public bool IsActive = true;
    public List<string> Permissions = new() { "AdminRead", "UserWrite" };
}