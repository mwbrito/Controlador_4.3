﻿//public void Process(User user)
//{
//    if (user == null) return;
//    if (!user.IsActive) return;
//    if (user.Permissions == null) return;

//    foreach (var p in user.Permissions.Where(p => p.StartsWith("Admin")))
//        Console.WriteLine("Admin: " + p);
//}