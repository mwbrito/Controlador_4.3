﻿//using System;
//using System.IO;

//public class LeitorDeArquivo
//{
//    public string LerConteudo(string caminho) => File.ReadAllText(caminho);
//}

//public class ContadorDePalavras
//{
//    public int Contar(string texto) => texto.Split(' ').Length;
//}

//public class Depois
//{
//    private readonly LeitorDeArquivo leitor = new();
//    private readonly ContadorDePalavras contador = new();

//    public void ContarPalavras(string caminho)
//    {
//        string conteudo = leitor.LerConteudo(caminho);
//        int total = contador.Contar(conteudo);
//        Console.WriteLine($"Total de palavras: {total}");
//    }
//}
