﻿using System;
using System;
using System.IO;

class Program
{
    static void Main()
    {
        int total = File.ReadAllText("teste.txt").Split(' ').Length;
        Console.WriteLine($"Total de palavras: {total}");

        Console.ReadKey();
    }
}