﻿//class Program
//{
//    static void Main()
//    {
//        var funcionario = new Funcionario("Lúcia", "Junior");

//        // Agora fica CLARO o que está acontecendo
//        funcionario.PromoverPara("Pleno");

//        Console.WriteLine($"{funcionario.Nome()} agora ocupa o cargo de {funcionario.Cargo()}");
//    }
//}


//public class Funcionario
//{
//    private string nome;
//    private string cargo;

//    public Funcionario(string nome, string cargoInicial)
//    {
//        this.nome = nome;
//        this.cargo = cargoInicial;
//    }

//    public void PromoverPara(string novoCargo)
//    {
//        // aqui você poderia incluir lógica de validação, regras, auditoria etc.
//        this.cargo = novoCargo;
//        Console.WriteLine($"{nome} foi promovido para {cargo}");
//    }

//    public string Nome() => nome;
//    public string Cargo() => cargo;
//}
