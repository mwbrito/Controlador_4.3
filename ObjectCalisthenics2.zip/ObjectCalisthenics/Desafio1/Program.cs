﻿using System;
using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        new Desafio().Listar();
        Console.ReadKey();
    }
}

public class Desafio
{
    public List<string> Produtos = new() { "Café", "Chá" };
    public void Listar()
    {
        foreach (var p in Produtos) Console.WriteLine(p);
    }
}
