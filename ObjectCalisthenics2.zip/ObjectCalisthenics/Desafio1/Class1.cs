﻿//using System;
//using System.Collections.Generic;

//public class ListaDeProdutos
//{
//    private List<string> produtos = new() { "Café", "Chá" };
//    public void Adicionar(string produto) => produtos.Add(produto);
//    public void MostrarTodos()
//    {
//        foreach (var p in produtos) Console.WriteLine(p);
//    }
//}

//public class Depois
//{
//    public ListaDeProdutos Produtos = new();
//    public void Listar() => Produtos.MostrarTodos();
//}
