﻿class Program
{
    static void Main()
    {
        var funcionario = new Funcionario { Nome = "Lúcia", Cargo = "Junior" };
        funcionario.Cargo = "Pleno";

        Console.WriteLine($"{funcionario.Nome} agora é {funcionario.Cargo}");

        Console.ReadKey();
    }
}

public class Funcionario
{
    public string Nome { get; set; }
    public string Cargo { get; set; }
}
