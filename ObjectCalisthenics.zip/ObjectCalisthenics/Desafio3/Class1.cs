﻿//class Program
//{
//    static void Main()
//    {
//        var cpf = new Cpf("12345678901");
//        var cliente = new Cliente("Maria", cpf);
//        cliente.Mostrar();
//    }
//}


//public class Cliente
//{
//    public string Nome { get; }
//    private readonly Cpf cpf;

//    public Cliente(string nome, Cpf cpf)
//    {
//        Nome = nome;
//        this.cpf = cpf;
//    }

//    public void Mostrar()
//    {
//        Console.WriteLine($"{Nome} - CPF: {cpf}");
//    }
//}

//public class Cpf
//{
//    private readonly string valor;

//    public Cpf(string valor)
//    {
//        if (!EhValido(valor))
//        {
//            throw new ArgumentException("CPF inválido");
//        }
//        this.valor = valor;
//    }

//    private bool EhValido(string cpf)
//    {
//        return cpf.Length == 11 && cpf.All(char.IsDigit);
//    }

//    public override string ToString()
//    {
//        return Convert.ToUInt64(valor).ToString(@"000\.000\.000\-00");
//    }
//}
