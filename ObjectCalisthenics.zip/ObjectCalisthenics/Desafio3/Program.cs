﻿class Program
{
    static void Main()
    {
        var cliente = new Cliente
        {
            Nome = "Maria",
            Cpf = "12345678900"
        };

        Console.WriteLine($"{cliente.Nome} - CPF: {cliente.Cpf}");

        Console.ReadKey();
    }
}


public class Cliente
{
    public string Nome { get; set; }
    public string Cpf { get; set; }
}
