﻿//var depois = new PedidoProcessor();
//depois.Processar(pedido);

//public class ValidadorDePedido
//{
//    public bool Validar(Pedido pedido)
//    {
//        if (string.IsNullOrWhiteSpace(pedido.Produto))
//        {
//            Console.WriteLine("Produto inválido.");
//            return false;
//        }

//        if (pedido.Quantidade <= 0)
//        {
//            Console.WriteLine("Quantidade inválida.");
//            return false;
//        }

//        return true;
//    }
//}

//public class CalculadoraDeFrete
//{
//    public decimal Calcular(Pedido pedido)
//    {
//        decimal frete = 10.0m;
//        if (pedido.Quantidade > 5)
//        {
//            frete += 5.0m;
//        }
//        return frete;
//    }
//}

//public class Notificador
//{
//    public void EnviarConfirmacao(Pedido pedido)
//    {
//        Console.WriteLine($"Enviando e-mail de confirmação para {pedido.Email}...");
//    }
//}

//public class PedidoProcessor
//{
//    private readonly ValidadorDePedido validador = new();
//    private readonly CalculadoraDeFrete freteCalc = new();
//    private readonly Notificador notificador = new();

//    public void Processar(Pedido pedido)
//    {
//        if (!validador.Validar(pedido)) return;

//        var frete = freteCalc.Calcular(pedido);
//        var total = pedido.Preco * pedido.Quantidade + frete;
//        Console.WriteLine($"Total do pedido: {total}");

//        notificador.EnviarConfirmacao(pedido);
//    }
//}
