﻿using System;

class Program
{
    static void Main()
    {
        var aluno = new Aluno
        {
            Nome = "Ana",
            Cpf = "123.456.789-00",
            Rua = "Rua das Flores",
            Cidade = "Curitiba",
            Escola = "Colégio Modelo",
            Serie = "8º ano"
        };

        aluno.ExibirFicha();

        Console.ReadKey();
    }
}

public class Aluno
{
    public string Nome;
    public string Cpf;
    public string Rua;
    public string Cidade;
    public string Escola;
    public string Serie;

    public void ExibirFicha()
    {
        Console.WriteLine($"Aluno: {Nome} ({Cpf})");
        Console.WriteLine($"Endereço: {Rua}, {Cidade}");
        Console.WriteLine($"Escola: {Escola} - Série: {Serie}");
    }
}

