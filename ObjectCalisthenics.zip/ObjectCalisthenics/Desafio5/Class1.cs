﻿//class Program
//{
//    static void Main()
//    {
//        var dados = new DadosPessoais { Nome = "Ana", Cpf = "123.456.789-00" };
//        var endereco = new Endereco { Rua = "Rua das Flores", Cidade = "Curitiba" };
//        var escolares = new DadosEscolares { Escola = "Colégio Modelo", Serie = "8º ano" };

//        var aluno = new Aluno(dados, endereco, escolares);
//        aluno.ExibirFicha();
//    }
//}


//public class DadosPessoais
//{
//    public string Nome;
//    public string Cpf;
//}

//public class Endereco
//{
//    public string Rua;
//    public string Cidade;
//}

//public class DadosEscolares
//{
//    public string Escola;
//    public string Serie;
//}

//public class Aluno
//{
//    private readonly DadosPessoais dados;
//    private readonly Endereco endereco;
//    private readonly DadosEscolares escolares;

//    public Aluno(DadosPessoais dados, Endereco endereco, DadosEscolares escolares)
//    {
//        this.dados = dados;
//        this.endereco = endereco;
//        this.escolares = escolares;
//    }

//    public void ExibirFicha()
//    {
//        Console.WriteLine($"Aluno: {dados.Nome} ({dados.Cpf})");
//        Console.WriteLine($"Endereço: {endereco.Rua}, {endereco.Cidade}");
//        Console.WriteLine($"Escola: {escolares.Escola} - Série: {escolares.Serie}");
//    }
//}
