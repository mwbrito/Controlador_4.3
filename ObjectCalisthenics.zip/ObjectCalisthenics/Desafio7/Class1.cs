﻿//public void Responder(int nota)
//{
//    if (nota >= 90) { Console.WriteLine("Excelente"); return; }
//    if (nota >= 70) { Console.WriteLine("Bom"); return; }
//    if (nota >= 50) { Console.WriteLine("Regular"); return; }
//    Console.WriteLine("Ruim");
//}