﻿class Program
{
    static void Main()
    {
        Responder(75);
        Console.ReadKey();
    }

    public static void Responder(int nota)
    {
        if (nota >= 90)
        {
            Console.WriteLine("Excelente");
        }
        else if (nota >= 70)
        {
            Console.WriteLine("Bom");
        }
        else if (nota >= 50)
        {
            Console.WriteLine("Regular");
        }
        else
        {
            Console.WriteLine("Ruim");
        }
    }
}
