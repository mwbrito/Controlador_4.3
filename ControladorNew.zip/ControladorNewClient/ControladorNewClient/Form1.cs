using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http.Json;

namespace ControladorNewClient
{
    public partial class Form1 : Form
    {
        private readonly HttpClient _httpClient;

        public Form1()
        {
            InitializeComponent();
            _httpClient = new HttpClient();
            LoadData("Controlador");  // Valor default para filtro
        }

        // Método para carregar os dados com base no filtro
        private async void LoadData(string filtro)
        {
            try
            {
                var response = await _httpClient.GetFromJsonAsync<Service[]>($"http://localhost:5000/services?filtro={filtro}");
                if (response != null)
                {
                    dataGridView1.DataSource = response;

                    if (dataGridView1.Columns.Count > 0)
                    {
                        dataGridView1.Columns[0].Width = 400; // Aumenta o espaço da coluna DisplayName
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar dados: {ex.Message}");
            }
        }

        // Evento do botão de buscar
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string filtro = txtFiltro.Text;  // Pega o valor do TextBox
            LoadData(filtro);  // Atualiza os dados na tabela com o filtro
        }

        // Classe Service para mapear o JSON da resposta
        public class Service
        {
            public string DisplayName { get; set; }
            public string Status { get; set; }
        }
    }
}
