using Microsoft.AspNetCore.Mvc;
using System.ServiceProcess;


[ApiController]
[Route("[controller]")]
public class ServicesController : ControllerBase
{
    [HttpGet]
    public IActionResult GetServices([FromQuery] string filtro = "")
    {
        var todosServicos = ServiceController.GetServices();
        var filtrados = todosServicos
            .Where(s => s.DisplayName.Contains(filtro, StringComparison.OrdinalIgnoreCase))
            .Select(s => new
            {
                s.DisplayName,
                s.ServiceName,
                Status = s.Status.ToString()
            });

        return Ok(filtrados);
    }
}
