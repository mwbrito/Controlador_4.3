using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Hosting.WindowsServices;

Host.CreateDefaultBuilder(args)
    .ConfigureServices((context, services) =>
    {
        services.AddControllers();
        services.AddHostedService<ApiBackgroundService>();
    })
    .UseWindowsService() // Torna o app um serviço do Windows
    .Build()
    .Run();
