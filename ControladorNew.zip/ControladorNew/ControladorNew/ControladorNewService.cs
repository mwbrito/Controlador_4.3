using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;

public class ApiBackgroundService : BackgroundService
{
    private IHost? _webHost;


    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _webHost = Host.CreateDefaultBuilder()
            .ConfigureWebHostDefaults(webBuilder =>
            {
                webBuilder.UseUrls("http://localhost:5000");
                webBuilder.ConfigureServices(services =>
                {
                    services.AddControllers();
                });

                webBuilder.Configure(app =>
                {
                    var env = app.ApplicationServices.GetRequiredService<IWebHostEnvironment>();

                    if (env.IsDevelopment())
                        app.UseDeveloperExceptionPage();

                    app.UseRouting();
                    app.UseEndpoints(endpoints =>
                    {
                        endpoints.MapControllers();
                    });
                });
            })
            .Build();

        await _webHost.StartAsync(stoppingToken);
    }

    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        if (_webHost != null)
        {
            await _webHost.StopAsync(cancellationToken);
            _webHost.Dispose();
        }
    }
}
