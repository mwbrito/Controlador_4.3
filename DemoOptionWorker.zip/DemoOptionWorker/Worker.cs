using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace DemoOptionWorker
{
    public class Worker : BackgroundService
    {
        private readonly IOptionsMonitor<AppSettings> _optionsMonitor;
        private IDisposable? _changeListener;

        public Worker(IOptionsMonitor<AppSettings> optionsMonitor)
        {
            _changeListener = optionsMonitor.OnChange(settings =>
            {
                Console.WriteLine($"⚡ Configuração alterada!");
                Console.WriteLine("===================================");
                foreach (var curva in settings.Curvas)
                {
                    Console.WriteLine($"Chave1: {curva.chave1}");
                    Console.WriteLine($"Chave2: {curva.chave2}");
                    Console.WriteLine("------------------------------------");
                }
                Console.WriteLine("===================================");
                Console.WriteLine("");
                Console.WriteLine("");
            });
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            Console.Clear();
            Console.WriteLine("-------------------------------------------------------------------------");   
            Console.WriteLine("👀 Monitorando configurações. Edite o minhasConfigs.json para ver mudanças.");   
            Console.WriteLine("-------------------------------------------------------------------------");   
        }

        public override void Dispose()
        {
            _changeListener?.Dispose();
            base.Dispose();
        }
    }
}
