public class AppSettings
{
    public List<Curva> Curvas { get; set; }
}

public class Curva
{
    public string chave1 { get; set; }
    public string chave2 { get; set; }
}
