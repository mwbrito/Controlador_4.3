﻿public class Configuracoes
{
    public string Ambiente { get; }

    public Configuracoes()
    {
        // Simulação de configuração carregada
        Ambiente = "Desenvolvimento";
    }
}
