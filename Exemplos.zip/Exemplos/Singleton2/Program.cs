﻿using Microsoft.Extensions.DependencyInjection;

class Program
{
    static void Main()
    {
        // Configura o container de DI
        var services = new ServiceCollection();
        services.AddSingleton<Configuracoes>(); // <- Singleton aqui!
        services.AddTransient<Aplicacao>();

        var serviceProvider = services.BuildServiceProvider();



        // Resolve e executa
        var app1 = serviceProvider.GetService<Aplicacao>();
        app1.Rodar();

        var app2 = serviceProvider.GetService<Aplicacao>();
        app2.Rodar();


        bool mesmaInstanciaApp = ReferenceEquals(app1, app2);
        Console.WriteLine($"App: Mesma instância? {mesmaInstanciaApp}");


        bool mesmaInstanciaConfig = ReferenceEquals(app1._config, app2._config);
        Console.WriteLine($"Config: Mesma instância? {mesmaInstanciaConfig}");
    }
}
