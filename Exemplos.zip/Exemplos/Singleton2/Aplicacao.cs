﻿public class Aplicacao
{
    public readonly Configuracoes _config;

    public Aplicacao(Configuracoes config)
    {
        _config = config;
    }

    public void Rodar()
    {
        Console.WriteLine($"Ambiente: {_config.Ambiente}");
    }
}
