﻿public class Aplicacao
{
    public Configuracoes config;
    public void Rodar()
    {
        config = Configuracoes.Instancia;

        Console.WriteLine($"Ambiente atual: {config.Ambiente}");
    }
}
