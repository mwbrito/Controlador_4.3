﻿class Program
{
    static void Main()
    {
        var app1 = new Aplicacao();
        app1.Rodar();

        var app2 = new Aplicacao();
        app2.Rodar();

        // Verificando que é a mesma instância
        bool mesmaInstanciaApp = ReferenceEquals(app1, app2);

        Console.WriteLine($"App: Mesma instância? {mesmaInstanciaApp}");


        bool mesmaInstanciaConfig = ReferenceEquals(app1.config, app2.config);

        Console.WriteLine($"Config: Mesma instância? {mesmaInstanciaConfig}");
    }
}
