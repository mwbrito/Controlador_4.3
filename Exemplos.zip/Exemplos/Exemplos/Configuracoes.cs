﻿public class Configuracoes
{
    private static Configuracoes _instancia;
    private static readonly object _lock = new();

    public string Ambiente { get; private set; }

    // Construtor privado
    private Configuracoes()
    {
        // Simulando leitura de arquivo ou banco de dados
        Ambiente = "Producao";
    }

    public static Configuracoes Instancia
    {
        get
        {
            lock (_lock)
            {
                return _instancia ??= new Configuracoes();
            }
        }
    }
}
