﻿public interface INotificador
{
    void Enviar(string mensagem);
}
