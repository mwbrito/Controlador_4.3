﻿public class NotificadorFactory
{
    public static INotificador Criar(string tipo)
    {
        return tipo.ToLower() switch
        {
            "email" => new NotificadorEmail(),
            "sms" => new NotificadorSms(),
            _ => throw new ArgumentException("Tipo de notificador inválido")
        };
    }
}
