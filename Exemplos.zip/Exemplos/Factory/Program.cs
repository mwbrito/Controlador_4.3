﻿class Program
{
    static void Main()
    {
        var app = new Aplicacao();
        app.Rodar();
    }
}
