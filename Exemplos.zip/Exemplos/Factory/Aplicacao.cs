﻿public class Aplicacao
{
    public void Rodar()
    {
        var notificador = NotificadorFactory.Criar("email");
        notificador.Enviar("Olá! Isso é uma notificação.");
    }
}
